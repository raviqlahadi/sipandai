# ci-boilerplate
Codeigniter Boilerplate for rapid develompment
