 <!-- CoreUI and necessary plugins-->
 <script src="<?php echo base_url() .  COREUI_PATH  ?>js/coreui.bundle.min.js"></script>