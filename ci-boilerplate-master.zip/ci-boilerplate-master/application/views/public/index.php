<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('public/part/head')?>
</head>
<body>
    <h1>This is America</h1>
</body>
</html>